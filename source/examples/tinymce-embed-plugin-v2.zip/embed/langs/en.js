tinyMCE.addI18n('en.embed',{
	desc : 'Insert Embed Code'
});
