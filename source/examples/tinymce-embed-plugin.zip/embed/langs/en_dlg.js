tinyMCE.addI18n('en.embed_dlg',{
	title : 'Insert Embed Code',
	tabone : 'Insert Embed Code'
});
